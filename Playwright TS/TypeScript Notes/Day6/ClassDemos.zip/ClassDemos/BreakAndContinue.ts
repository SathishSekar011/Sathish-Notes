//break
/*
for(let i=1;i<=10;i++)
{
 
    if(i==5)
    {
        break;
    }
    console.log(i);
    
}
*/

//continue

for(let i=1;i<=10;i++)
    {
     
        if(i==3 ||  i==5 || i==7)
        {
            continue;
        }
        console.log(i);
        
    }