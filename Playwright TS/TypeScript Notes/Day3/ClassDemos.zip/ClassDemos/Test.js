// JS is Dynamically Typed Programming Language

let age=30;  // age a number
console.log(typeof(age));  //Number


age="Thirty"   //String   //No complier error
console.log(typeof(age)); //string


console.log(age);  // Thirty



//Type Safety - Not

/*
let message="Hello"   //String
message=100;  // No compiler error you can assign any type of data. There is No Type safty
*/


/*
let result="5"+3;  //No compiler error, No TypeSfety
console.log(result);
*/

