//Single line comment    
    // Windows :   ctrl+/
    // Mac:         Cmd + /


// Multiline comment    
    // Windows:     Shift+Alt+A
    // Mac:        Shift+Option+A



//Examples:


// console.log("welcome")


/*console.log("welcome")
console.log("welcome")
console.log("welcome")
console.log("welcome")
*/